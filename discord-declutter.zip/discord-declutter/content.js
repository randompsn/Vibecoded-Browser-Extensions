/* Discord Declutter - content.js
 *
 * Discord's class names are hashed and change often, so this script relies on
 * attributes that are stable instead:
 *   [data-list-id="guildsnav"]            the server list
 *   [data-list-item-id^="guildsnav___"]   one entry (suffix = guild id)
 *   [data-dnd-name]                       holds the server's name
 *
 * It only sets attributes on existing elements (never adds or removes nodes),
 * so it can't conflict with React. content.css does the visual work.
 */
(() => {
  'use strict';

  const TREE_SEL = '[data-list-id="guildsnav"]';
  const ITEM_SEL = '[data-list-item-id^="guildsnav___"]';
  const ITEM_PREFIX = 'guildsnav___';
  // Guild ids are snowflakes (17-20 digits). This skips the Home button,
  // "Add a Server", "Discover" and "Download Apps" entries.
  const GUILD_ID = /^\d{15,}$/;

  function currentGuildId() {
    const m = location.pathname.match(/^\/channels\/(\d+)/);
    return m ? m[1] : null;
  }

  function apply() {
    const tree = document.querySelector(TREE_SEL);
    if (!tree) return;

    const nav = tree.closest('nav') || tree.parentElement;
    if (nav) nav.setAttribute('data-dsn-nav', '');

    const activeId = currentGuildId();

    for (const item of tree.querySelectorAll(ITEM_SEL)) {
      const id = item.getAttribute('data-list-item-id').slice(ITEM_PREFIX.length);
      if (!GUILD_ID.test(id)) continue;
      if (item.querySelector(ITEM_SEL)) continue; // a container of entries, not one entry

      const row = item.closest('[data-dnd-name]') || item.querySelector('[data-dnd-name]');
      if (!row || !tree.contains(row)) continue;
      if (row.querySelectorAll(ITEM_SEL).length > 1) continue; // e.g. a whole folder

      row.setAttribute('data-dsn-row', '');
      row.toggleAttribute('data-dsn-active', id === activeId);

      // Make every container between the <nav> and the row fill the new width.
      for (let el = row.parentElement; el && el !== nav; el = el.parentElement) {
        if (el.hasAttribute('data-dsn-fill')) break;
        el.setAttribute('data-dsn-fill', '');
      }
    }
  }

  // The real avatar is hidden, so clicks land on the row itself. Re-dispatch
  // them on the hidden avatar so Discord's own handlers (navigate, context
  // menu) run exactly as before.
  function forward(e) {
    const row = e.target instanceof Element && e.target.matches('[data-dsn-row]') ? e.target : null;
    if (!row) return;
    const inner = row.querySelector(ITEM_SEL) || row.querySelector('[role="treeitem"]');
    if (!inner) return; // handler lives on an ancestor; the event reaches it natively
    e.stopPropagation();
    const clone = new MouseEvent(e.type, e);
    if (!inner.dispatchEvent(clone)) e.preventDefault();
  }
  document.addEventListener('click', forward, true);
  document.addEventListener('contextmenu', forward, true);

  // Discord is a single-page app: re-apply whenever the DOM changes
  // (throttled to once per frame).
  let queued = false;
  const schedule = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      apply();
    });
  };
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
  schedule();
})();
