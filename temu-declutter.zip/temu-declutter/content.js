/* Temu Declutter - content.js
 *
 * Temu is a client-rendered app with hashed class names, so nothing here
 * depends on class names. It works from things that stay put: product link
 * format (...-g-<id>.html), "See more" controls, price text and computed
 * styles. It only edits text-node contents and sets data-* attributes (never
 * adds or removes elements), so it can't conflict with React. content.css
 * does the hiding and graying.
 */
(() => {
  'use strict';

  const CONFIG = {
    roundPrices: true, // >= $1 rounds up to whole dollars; < $1 keeps its cents
    grayPromos: true,  // gray promo badges, sale prices and promo pop-ups (campaign links: CSS)
    removeFeed: true   // hide the product feed on the home (dashboard) page only
  };

  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION']);
  const NAV_SEL = 'nav, footer, [role="navigation"], [role="menu"], [role="menubar"]';
  const OVERLAY_SEL = 'header, footer, nav, aside, [role="dialog"], [aria-modal="true"]';

  /* ------------------------------------------------------------------ */
  /* Price rounding                                                      */
  /* ------------------------------------------------------------------ */

  const PRICE_G = /(\$\s*)(\d[\d,]*)(?:\.(\d+))?/g;
  const PRICE_ONE = /(\$\s*)(\d[\d,]*)(?:\.(\d+))?/;
  // One price (optionally with a short unit like "/pc"), possibly split across elements.
  const SINGLE_PRICE = /^\$\s*\d[\d,]*(?:\.\d+)?(?:\s*\/?\s*[^\d\s$]{1,6})?$/;
  const SINGLE_PRICE_WITH_CENTS = /^\$\s*\d[\d,]*\.\d+(?:\s*\/?\s*[^\d\s$]{1,6})?$/;

  // Returns the rounded number text, or null when nothing should change.
  function roundUp(intStr, fracStr) {
    const intVal = parseInt(intStr.replace(/,/g, ''), 10);
    if (Number.isNaN(intVal)) return null;
    const frac = fracStr || '';
    const original = intStr + (fracStr !== undefined ? '.' + fracStr : '');
    let out;
    if (intVal >= 1) {
      const v = intVal + (/[1-9]/.test(frac) ? 1 : 0);
      out = intStr.includes(',') ? v.toLocaleString('en-US') : String(v);
    } else {
      if (frac.length <= 2) return null; // ordinary cents price under $1: keep it
      const cents = parseInt(frac.slice(0, 2), 10) + (/[1-9]/.test(frac.slice(2)) ? 1 : 0);
      out = cents >= 100 ? '1' : '0.' + String(cents).padStart(2, '0');
    }
    return out === original ? null : out;
  }

  function roundText(str) {
    return str.replace(PRICE_G, (m, sym, i, f) => {
      const r = roundUp(i, f);
      return r === null ? m : sym + r;
    });
  }

  function textNodesOf(el) {
    const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    const out = [];
    for (let n = w.nextNode(); n; n = w.nextNode()) out.push(n);
    return out;
  }

  // Highest ancestor (max 3 levels, short text) whose whole text is one price.
  function priceContainer(t, re) {
    let best = null;
    let c = t.parentElement;
    for (let i = 0; i < 4 && c; i++, c = c.parentElement) {
      const txt = c.textContent.trim();
      if (txt.length > 24) break;
      if (re.test(txt)) best = c;
      else if (best) break;
    }
    return best;
  }

  // Price split over elements, e.g. <span>$</span><span>3</span><span>.99</span>
  function rewriteSplit(container) {
    const nodes = textNodesOf(container);
    const full = nodes.map((n) => n.data).join('');
    const m = PRICE_ONE.exec(full);
    if (!m) return;
    const r = roundUp(m[2], m[3]);
    if (r === null) return;
    const start = m.index + m[1].length;
    const end = m.index + m[0].length;
    let pos = 0;
    let placed = false;
    for (const n of nodes) {
      const s = n.data;
      const a = pos;
      pos += s.length;
      const from = Math.max(a, start);
      const to = Math.min(pos, end);
      if (from >= to) continue;
      const mid = placed ? '' : ((placed = true), r);
      const next = s.slice(0, from - a) + mid + s.slice(to - a);
      if (next !== s) n.data = next;
    }
  }

  function roundNode(t) {
    const s = t.data;
    const next = roundText(s);
    if (next !== s) t.data = next;
    // Node ends with "$" or "$3" and the cents may live in the next element.
    if (!/\.\d/.test(s) && (s.trim() === '$' || /\$\s*\d[\d,]*\.?\s*$/.test(s))) {
      const c = priceContainer(t, SINGLE_PRICE_WITH_CENTS);
      if (c) rewriteSplit(c);
    }
  }

  /* ------------------------------------------------------------------ */
  /* Promotions (gray)                                                   */
  /* ------------------------------------------------------------------ */

  // English promo wording. (Sale-coloured and struck-through prices are
  // detected from styles, so those work in any language.)
  const PROMO_RE = new RegExp(
    [
      '\\bsale\\b', '\\bdeals?\\b', '\\boff\\b', '\\bsave\\b', 'coupon', 'promo', 'discount',
      'clearance', '\\bbogo\\b', 'lightning', 'flash', 'limited[- ]time', 'free (?:delivery|shipping|gift)',
      'bundle', 'rewards?\\b', 'credit', 'almost sold out', 'only \\d+ left', 'ends in',
      '\\bextra\\b', '[-−]\\s*\\d+\\s*%', '\\d+\\s*%\\s*off'
    ].join('|'),
    'i'
  );

  const checked = new WeakSet();
  const gray = (el) => el.setAttribute('data-td-gray', '');

  function parseRgb(str) {
    const m = /rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/.exec(str || '');
    return m ? [+m[1], +m[2], +m[3]] : null;
  }

  // Saturated red/orange: the colour sale prices and promo tags use.
  function isPromoColor(rgb) {
    if (!rgb) return false;
    const [r, g, b] = rgb;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const d = max - min;
    if (d < 80) return false;
    const l = (max + min) / 510;
    const s = d / (255 * (1 - Math.abs(2 * l - 1)));
    if (s < 0.5 || l < 0.2 || l > 0.75) return false;
    let h;
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
    return h <= 45 || h >= 335;
  }

  function struck(el) {
    for (let i = 0, e = el; i < 3 && e; i++, e = e.parentElement) {
      const d = getComputedStyle(e).textDecorationLine;
      if (d && d.includes('line-through')) return true;
    }
    return false;
  }

  // Struck-through list prices and orange/red sale prices.
  function grayPrice(t, el) {
    const c = priceContainer(t, SINGLE_PRICE) || el;
    if (checked.has(c)) return;
    checked.add(c);
    if (c.closest('[data-td-gray]') || c.closest(NAV_SEL)) return;
    const red = isPromoColor(parseRgb(getComputedStyle(c).color)) || isPromoColor(parseRgb(getComputedStyle(el).color));
    if (red || struck(c) || struck(el)) gray(c);
  }

  // Short promo text ("-70%", "Free shipping", "Lightning deal"): gray the
  // badge/bar around it. A pop-up containing promo text is grayed whole.
  function grayBadge(t, el) {
    const dialog = el.closest('[role="dialog"], [aria-modal="true"]');
    if (dialog) gray(dialog);
    if (el.childElementCount) return;
    if (el.closest('[data-td-gray]') || el.closest('button, [role="button"], ' + NAV_SEL)) return;
    const len = t.data.trim().length;
    let target = el;
    for (let i = 0; i < 3 && target.parentElement; i++) {
      const p = target.parentElement;
      if (p.matches('a, li, article, section, main') || p.textContent.trim().length > len + 12) break;
      target = p;
    }
    gray(target);
  }

  /* ------------------------------------------------------------------ */
  /* Feed removal (home page only)                                       */
  /* ------------------------------------------------------------------ */

  // "/", "/home.html", or a bare locale such as "/us" or "/ca-fr".
  const isDashboard = () => /^\/(?:home\.html|[a-z]{2}(?:-[a-z]{2,4})?)?\/?$/i.test(location.pathname);

  const PRODUCT_HREF = /-g-\d{6,}\.html|goods\.html\?[^#]*goods_id=/i;
  const MORE_TEXT = /^(?:see|view|load|show)\s+(?:more|all)$|^more$/i;

  const isProductLink = (a) => PRODUCT_HREF.test(a.getAttribute('href') || '');
  const isMore = (el) => MORE_TEXT.test(el.textContent.trim().replace(/\s*[>›»→]+$/, ''));
  const inContent = (el) => !el.closest(OVERLAY_SEL);

  const hideable = (el) =>
    !el.matches('html, body, header, footer, nav') && !el.querySelector('header, footer, nav, input, form');
  const markFeed = (el) => {
    if (hideable(el)) el.setAttribute('data-td-feed', '');
  };

  // Loader / sentinel / skeleton: nothing worth seeing.
  const isSubstantive = (el) => {
    if (el.matches('script, style, link, template, noscript') || el.hasAttribute('data-td-feed')) return false;
    const text = el.textContent.trim();
    if (MORE_TEXT.test(text)) return false;
    if (el.querySelector('a, button, img, picture, video, input')) return true;
    return text.length > 0;
  };
  // Short heading with no links/images: the feed's own title.
  const isTitleLike = (el) => !el.querySelector('a, button, img, picture, input') && el.textContent.trim().length <= 60;

  function updateFeed() {
    if (!isDashboard()) {
      document.querySelectorAll('[data-td-feed]').forEach((e) => e.removeAttribute('data-td-feed'));
      return;
    }

    // Everything that belongs to the feed: product cards and "See more" controls.
    const set = new Set();
    for (const a of document.querySelectorAll('a[href]')) {
      if (isProductLink(a) && inContent(a)) set.add(a);
    }
    for (const el of document.querySelectorAll('a, button, [role="button"]')) {
      if (isMore(el) && inContent(el)) set.add(el);
    }
    const items = [...set];
    if (items.length === 0) return;

    // The container that holds the feed modules; each of its children that
    // contains feed items is one module.
    let lca = items[0];
    for (const el of items) {
      while (!lca.contains(el)) lca = lca.parentElement;
    }
    if (set.has(lca)) lca = lca.parentElement;

    const tooHigh = !lca || lca.matches('html, body, #__next, #root') || lca.querySelector('header, footer');
    if (tooHigh) {
      // Fallback: hide each item's own card/row (module titles may remain).
      for (const el of items) {
        if (el.closest('[data-td-feed]')) continue;
        let c = el;
        while (c.parentElement && items.filter((x) => c.parentElement.contains(x)).length === 1) {
          c = c.parentElement;
        }
        markFeed(c);
      }
      return;
    }

    for (const el of items) {
      if (el.closest('[data-td-feed]')) continue;
      let c = el;
      while (c.parentElement !== lca) c = c.parentElement;
      markFeed(c);
    }

    // Lazy loading is usually triggered by a sentinel/spinner next to the feed.
    // Hidden items would leave it permanently in view and fetch pages forever,
    // so hide the whole feed region, loaders and titles included.
    let node = lca;
    for (const ch of lca.children) {
      if (!ch.hasAttribute('data-td-feed') && !isSubstantive(ch)) markFeed(ch);
    }
    if ([...lca.children].every((ch) => ch.hasAttribute('data-td-feed'))) {
      for (let depth = 0; depth < 4; depth++) {
        const p = node.parentElement;
        if (!p || p === document.body || p === document.documentElement || p.querySelector('header, footer')) break;
        const sibs = [...p.children].filter((s) => s !== node);
        let real = false;
        for (const s of sibs) {
          if (s.hasAttribute('data-td-feed')) continue;
          if (!isSubstantive(s) || isTitleLike(s)) markFeed(s);
          else real = true;
        }
        if (real) break;
        node = p;
      }
      markFeed(node);
    }
  }

  /* ------------------------------------------------------------------ */
  /* Driver                                                              */
  /* ------------------------------------------------------------------ */

  function handleText(t) {
    const el = t.parentElement;
    if (!el || SKIP_TAGS.has(el.tagName)) return;
    const raw = t.data;
    if (!raw.trim()) return;
    if (CONFIG.roundPrices && raw.indexOf('$') !== -1) roundNode(t);
    if (CONFIG.grayPromos) {
      const s = t.data.trim();
      if (s.indexOf('$') !== -1) grayPrice(t, el);
      if (s.length <= 30 && PROMO_RE.test(s)) grayBadge(t, el);
    }
  }

  function scan(root) {
    if (!root || !root.isConnected) return;
    if (root.nodeType === Node.TEXT_NODE) return handleText(root);
    if (root.nodeType !== Node.ELEMENT_NODE || SKIP_TAGS.has(root.tagName)) return;
    for (const t of textNodesOf(root)) handleText(t);
  }

  const pending = new Set();
  let timer = 0;

  function flush() {
    timer = 0;
    const roots = [...pending];
    pending.clear();
    for (const r of roots) scan(r);
    if (CONFIG.removeFeed) updateFeed();
  }

  function queue(node) {
    pending.add(node);
    if (!timer) timer = setTimeout(flush, 120);
  }

  function start() {
    scan(document.body);
    if (CONFIG.removeFeed) updateFeed();
    // Our own text edits re-trigger this once; the second pass changes nothing.
    new MutationObserver((muts) => {
      for (const m of muts) {
        if (m.type === 'characterData') queue(m.target);
        else for (const n of m.addedNodes) queue(n);
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  // Give the page time to hydrate first, so our edits don't collide with it.
  if (document.readyState === 'complete') setTimeout(start, 500);
  else window.addEventListener('load', () => setTimeout(start, 500), { once: true });
})();
